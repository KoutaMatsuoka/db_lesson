Q1
  create table departments (
    -> department_id INT unsigned NOT NULL auto_increment primary key,
    -> name VARCHAR(20) NOT NULL,
    -> created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -> updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
    -> );

Q2
  ALTER TABLE people ADD department_id INT unsigned AFTER email;

Q3
  insert into departments (name)
    -> values
    -> ('営業'),
    -> ('開発'),
    -> ('経理'),
    -> ('人事'),
    -> ('情報システム');

  insert into people (name, department_id)
    -> values
    -> ('営業1', 1),
    -> ('営業2', 1),
    -> ('営業3', 1),
    -> ('開発1', 2),
    -> ('開発2', 2),
    -> ('開発3', 2),
    -> ('開発4', 2),
    -> ('経理', 3),
    -> ('人事', 4),
    -> ('情報システム', 5);

  insert into reports (person_id, content)
    -> values
    ->  (8, 'テストデータその1'),
    ->  (10, 'テストデータその2'),
    ->  (15, 'テストデータその3'),
    ->  (11, 'テストデータその4'),
    ->  (14, 'テストデータその5'),
    ->  (14, 'テストデータその6'),
    ->  (16, 'テストデータその7'),
    ->  (12, 'テストデータその8'),
    ->  (7, 'テストデータその9'),
    ->  (9, 'テストデータその10');

Q4

Q5

Q6

テーブル・レコード・カラムという3つの単語を適切に使用して、下記のSQL文を日本語で説明してください。

SELECT
  `name`, `email`, `age`
FROM
  `people`
WHERE
  `department_id` = 1
ORDER BY
  `created_at`;


`SELECT `name`, `email`, `age` FROM `people` WHERE `department_id` = 1 ORDER BY `created at` `
Q7

Q8

Q9
  
Q10

Q11
